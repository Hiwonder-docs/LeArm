#include <Wire.h>
#include "Ultrasound.hpp"

Ultrasound::Ultrasound()
{
  iic = nullptr;
}

void Ultrasound::init(IIC* iic_obj)
{
  iic = iic_obj;
}

// Set ultrasonic RGB to breathing light mode （设置超声波rgb为呼吸灯模式）
// r1, g1, b1 represent the breathing cycle of the right RGB light, e.g., 20, 20, 20 means a 2-second cycle （r1，g1，b1表示右边rgb灯的呼吸周期，例如20，20，20，表示2秒一个周期）
// r2, g2, b2 represent the breathing cycle of the left RGB light （r2，g2，b2表示左边rgb灯的呼吸周期）
void Ultrasound::Breathing(uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2)
{
  uint8_t breathing[6]; 
  uint8_t value = RGB_WORK_BREATHING_MODE;
  
  iic->wireWriteDataArray(ULTRASOUND_I2C_ADDR, RGB_WORK_MODE, &value, 1);
  breathing[0] = r1;breathing[1] = g1;breathing[2] = b1;//RGB1 blue （RGB1 蓝色）
  breathing[3] = r2;breathing[4] = g2;breathing[5] = b2;//RGB2
  iic->wireWriteDataArray(ULTRASOUND_I2C_ADDR, RGB1_R_BREATHING_CYCLE,breathing,6); //Send color value （发送颜色值）
}

// Set the color of the ultrasonic RGB light （设置超声波rgb灯的颜色）
// r1, g1, b1 represent the proportion of the three primary colors of the right RGB light, range 0-255 （r1，g1，b1表示右边rgb灯的三原色的比例，范围0-255）
// r2, g2, b2 represent the proportion of the three primary colors of the left RGB light, range 0-255 （r2，g2，b2表示左边rgb灯的三原色的比例，范围0-255）
void Ultrasound::Color(uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2)
{
  uint8_t RGB[6]; 
  uint8_t value = RGB_WORK_SIMPLE_MODE;
  
  iic->wireWriteDataArray(ULTRASOUND_I2C_ADDR, RGB_WORK_MODE,&value,1);
  RGB[0] = r1;RGB[1] = g1;RGB[2] = b1;//RGB1
  RGB[3] = r2;RGB[4] = g2;RGB[5] = b2;//RGB2
  iic->wireWriteDataArray(ULTRASOUND_I2C_ADDR, RGB1_R,RGB,6);
}

//Get the distance measured by the ultrasonic sensor in mm （获取超声波测得的距离单位mm）
uint16_t Ultrasound::GetDistance()
{
  uint16_t distance;
  iic->wireReadDataArray(ULTRASOUND_I2C_ADDR, 0,(uint8_t *)&distance,2);
  return distance;
}
